// Temporary el-55qcdj experiment: same schedule as the list scaling test, but
// records every per-query duration so several estimators can be compared on
// identical data. Not part of the repository.
import { loadavg } from 'node:os';
const WT = process.argv[2];
const { QuarryAPIImpl } = await import(`${WT}/packages/quarry/src/api/quarry-api.ts`);
const { createStorage, initializeSchema } = await import(`${WT}/packages/storage/src/index.ts`);
const { createTask } = await import(`${WT}/packages/core/src/index.ts`);

const ORDERS = [[0, 1, 2], [2, 1, 0], [1, 2, 0], [0, 2, 1], [2, 0, 1], [1, 0, 2]];
const SIZES = [50, 100, 150];
const QUERIES = 256;

async function sample(size: number, quadratic = false): Promise<number[]> {
  const storage = createStorage({ path: ':memory:' });
  try {
    initializeSchema(storage);
    const api = new QuarryAPIImpl(storage);
    for (let i = 0; i < size; i++) {
      const id = `el-${crypto.randomUUID().replace(/-/g, '').substring(0, 8)}`;
      await api.create(await createTask({ id, title: `P-${id}`, createdBy: 'user:x', tags: ['perf-test'] }));
    }
    const list = async () => {
      const r = await api.list({ type: 'task', limit: size });
      if (quadratic) for (const _ of r) await api.list({ type: 'task', limit: size });
      return r;
    };
    await list();
    const d: number[] = [];
    for (let q = 0; q < (quadratic ? 16 : QUERIES); q++) {
      const s = performance.now();
      await list();
      d.push(performance.now() - s);
    }
    return d;
  } finally {
    storage.close();
  }
}

const q = (v: number[], p: number) => { const s = [...v].sort((a, b) => a - b); return s[Math.min(s.length - 1, Math.floor(p * (s.length - 1)))]; };
const med = (v: number[]) => { const s = [...v].sort((a, b) => a - b); const m = s.length / 2; return (s[Math.floor(m)] + s[Math.ceil(m) - 1]) / 2; };
const mean = (v: number[]) => v.reduce((a, b) => a + b, 0) / v.length;

const quadratic = process.argv[3] === 'quadratic';
for (const s of SIZES) await sample(s, quadratic);
const samples: number[][][] = SIZES.map(() => []);
for (const o of ORDERS) for (const i of o) samples[i].push(await sample(SIZES[i], quadratic));
const est = {
  medianOfMeans: samples.map((g) => med(g.map(mean))),
  minAll: samples.map((g) => Math.min(...g.flat())),
  medianOfSampleMins: samples.map((g) => med(g.map((x) => Math.min(...x)))),
  medianOfSampleP10: samples.map((g) => med(g.map((x) => q(x, 0.1)))),
  medianOfSampleMedians: samples.map((g) => med(g.map(med))),
  p10All: samples.map((g) => q(g.flat(), 0.1)),
  p25All: samples.map((g) => q(g.flat(), 0.25)),
};
const ratios = Object.fromEntries(Object.entries(est).map(([k, v]) => [k, +(v[2] / v[0]).toFixed(4)]));
console.log(JSON.stringify({ ratios, est, loadavg: loadavg().map((x) => +x.toFixed(2)) }));
